const Index = () => (
    <div>
      <p>Sample app using React and Next.js</p>
    </div>
  );
  
  export default Index;